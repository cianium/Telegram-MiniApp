# Product scope — MVP and future version

## Implemented in MVP source

- Telegram launch bot: `/start`, `/help`, HTTPS WebApp launch button.
- Signed Telegram authentication and signed session token (24 hours).
- Demo-only localhost login, disabled outside DEV_MODE.
- Validated public HTTPS video/audio URLs: YouTube, Instagram, SoundCloud, TikTok, Vimeo (depending on yt-dlp compatibility).
- Media metadata, dynamic available quality choices, MP3 audio extraction, file-size checks.
- Responsive mobile-first React UI, Persian/English, dark design and device-friendly interactions.
- **Music tab:** title/artist/album search via MusicBrainz metadata; licensed downloadable music via Jamendo when `JAMENDO_CLIENT_ID` is configured; artist-permission checks at API and Worker levels.
- Separate catalog vs downloadable results, license links, authorized MP3 delivery as Telegram audio.
- Background download and bot delivery, status polling, cancellation, user-scoped history and deletion, basic aggregate admin stats.
- Rate limits for metadata preview and jobs; security baseline; temporary file cleanup.
- SQLite local dev; PostgreSQL and Redis/RQ deployment scaffold; tests and development documentation.

## Product features planned after validating MVP

- Batch and playlist downloads when permitted, with stricter quotas.
- Optional private cloud delivery/storage with retention rules.
- Native bot deep-link to preload media URL in Mini App.
- Advanced job retry control, crash recovery and notifications.
- Advanced admin dashboard, analytics, quotas, moderation and fraud detection.
- Other music catalogs via official metadata APIs (e.g. Spotify *metadata and original links only*, not music download).
- Custom internationalization and advanced accessibility improvements.
- Richer download history with text search, filters and tags.

## Important boundaries

- No guarantee that all video/audio URLs are technically supported.
- No DRM/access-control bypass or credentials/cookie import.
- File delivery currently uses public Telegram Bot API default upload limit.
- Does not download Spotify audio.
- Does not support playlist, bulk, livestream or private links in MVP.
