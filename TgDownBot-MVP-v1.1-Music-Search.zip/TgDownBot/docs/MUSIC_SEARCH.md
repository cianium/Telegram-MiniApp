# Music Search module — Tg DownBot MVP v1.1

This module was developed and tested locally but is **not yet live-tested with music provider credentials**.

## User experience

**Music** is a bottom-navigation tab independent from the URL downloader:

- Query any title, artist, or album by typing in the search box.
- **Music catalog:** MusicBrainz recordings metadata, including title, artist, album, duration and a source-page link. Catalog hits have no download button.
- **Downloadable:** Jamendo tracks. Only results with `audiodownload_allowed = true` *and* a Jamendo-controlled media URL display a download button. Licensing links are displayed when provided.
- Clicking the download button queues the track to be delivered as MP3 audio in the Telegram bot chat.
- If a download is queued, the UI returns to Home and shows the existing job progress/history.

This is **not** a mechanism to download copyrighted audio from Spotify, Apple Music, or all commercial catalogues. The broad catalog and the downloadable catalog are different on purpose.

## Backend/API

Authenticated endpoints:

- `GET /api/music/search?q=search&source=catalog`: MusicBrainz recording search (up to 20 results, not downloadable)
- `GET /api/music/search?q=search&source=downloadable`: Jamendo search (up to 25 results); returns `configured=false` without a Jamendo API client ID
- `POST /api/music/jobs` JSON `{"track_id": 23456}`: server fetches Jamendo track, verifies artist consent and recognized audio host, stores a canonical track URL, and creates the existing audio job
- Existing `GET /api/jobs/{id}` and history routes are used for progress

## Running locally

No VPS needed: follow README local instructions. The Jamendo Client ID is set server-side via `JAMENDO_CLIENT_ID` in `.env` (see `.env.example`). The source code does not bundle a Client ID.

To test the **interface without any external network**, use `SIMULATE_DOWNLOAD=true` to test download job progress using mocked backend tests; the real music search still needs provider network access, and Jamendo result search needs your own Client ID. Set `SIMULATE_DOWNLOAD=false` only when ready to test real Telegram delivery from a verified Telegram account.

## Permissions and network safety

- The UI's `downloadable` flag is never used as authorization.
- The API verifies Jamendo track availability and downloads allowed before queueing.
- The worker rechecks the same conditions immediately before streaming.
- The worker resolves source file URLs from Jamendo API (not from user-supplied links), permits only `https://*.storage.jamendo.com`, revalidates redirects, rejects oversized files, and deletes temporary files.
- User-scoped session tokens, job quotas and one-active-job rule are inherited from original Tg DownBot API.

## Release checklist

- [x] Backend routes and offline music unit/integration tests
- [x] Music UI source and TypeScript parse
- [ ] `npm install && npm run build` in a network-connected development environment
- [ ] Real MusicBrainz metadata search, verifying 1 request/sec rate limit behavior
- [ ] Real Jamendo search using app-specific Client ID
- [ ] Download artist-approved sample and send it with `sendAudio` to a real Telegram user
- [ ] Telegram mini-app signed login test (HTTPS)
- [ ] Redis global rate-limit gate and caching for multi-instance MusicBrainz calls
- [ ] Full deployment hardening, database migrations, worker egress policy and concurrent job limits
