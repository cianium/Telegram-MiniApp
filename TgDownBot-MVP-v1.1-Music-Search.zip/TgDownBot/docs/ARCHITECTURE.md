# Tg DownBot — Architecture v1.0

## Boundaries

- `frontend`: React + Vite single-page Mini App. Never holds Telegram bot secret.
- `backend/app`: FastAPI. Validates signed initData, issues 24-hour signed sessions; scopes jobs to Telegram user ID.
- `backend/worker`: RQ consumer. Downloads content using yt-dlp, converts using FFmpeg, sends permitted output via Telegram API, then deletes temporary files.
- `backend/bot.py`: Telegram command adapter; /start contains launch button when HTTPS URL configured.
- `PostgreSQL`: user/jobs state. SQLite is used only for lightweight local developer tests.
- `Redis`: persistent queue for deployment. Thread pool fallback for DEV_MODE=true (not production-safe).

## User flow

Mini App → `POST /api/auth/telegram` → signed session token → `POST /api/media/analyze` → `POST /api/jobs` → Redis queue → worker → Telegram `sendDocument` or `sendAudio` → `GET /api/jobs/:id` polling → success.

## API

- `GET /api/health` public status
- `POST /api/auth/telegram` validate Telegram data
- `POST /api/auth/demo` only for localhost and development
- `GET /api/me` user profile
- `POST /api/media/analyze` validate/extract metadata
- `GET /api/music/search?q=...&source=catalog|downloadable` MusicBrainz catalog or Jamendo authorized tracks
- `POST /api/music/jobs` accepts Jamendo track ID only; server re-checks download consent
- `POST /api/jobs` validate/start job, daily quota and one active job per user
- `GET /api/jobs` user history, max 30
- `DELETE /api/history` remove terminal history for current user
- `GET /api/jobs/{id}` one user's job status
- `DELETE /api/jobs/{id}` request cancellation
- `GET /api/admin/stats` admin-only aggregate statistics

## Security baseline

- Strict Telegram HMAC signature + initData age validation, HMAC-signed short-lived API session.
- Do not trust `initDataUnsafe` or client-supplied user IDs.
- HTTPS-only provider host allowlist. Reject direct IPs, non-standard ports and redirect parameters. This is *not* a complete anti-SSRF network sandbox: deploy worker in an isolated container/network with private IP egress blocked before enabling untrusted users.
- No support for DRM bypass or retrieving restricted/private media.
- No cookies, credential injection or user-provided custom yt-dlp flags.
- Artist-approved Jamendo music only. Track IDs are resolved from Jamendo server-side, checked for download consent twice; streamed audio has size cap and strict domain/redirect allowlist.
- One active job/user; daily quota; max output size before Bot API upload; temp file deletion.
- Errors deliberately generic to prevent disclosing URLs/token details.
- Auth, jobs, and admin authorization require additional load/security testing prior to public exposure.

## Known limitations / next hardening

1. No robust distributed atomic quota / active-job reservation against concurrent HTTP requests yet.
2. `yt-dlp` may follow CDN URLs and redirects. Isolate worker egress and add outbound proxy policy before production use.
3. FFmpeg can produce high resource load; constrain CPU/memory and filesystem via orchestration.
4. No migrations yet (SQLAlchemy `create_all`), no backup/restore playbook or structured metrics/alerting.
5. No automatic retries after crash; queued states can stall if RQ jobs fail without triggering task handler.
6. Metadata analysis is offloaded to a thread and has a Redis-backed rate limiter; timeout cancellation does not forcibly terminate a stuck extractor thread. Isolate metadata extraction in a constrained process before public use.
7. Local Bot API server support is not configured, so default public Bot API file limit applies.
8. MusicBrainz has a one-request-per-second service limit. Current single-process limiter is insufficient across multiple API workers; introduce Redis-backed global throttling and cache before scaled production.
9. Jamendo downloads require a separately registered API client ID; access, consent and availability vary by artist.
10. External platforms may change their supported extraction requirements; compatibility requires periodic maintenance.

## Content scope

Support only files users own or are authorized to download. Spotify is not a downloadable audio source here. Unsupported/private content returns a controlled error. Use legitimate platform APIs where required.
