import os
from pathlib import Path

# Configure isolated SQLite test database BEFORE importing the application.
TEST_DB = Path(__file__).with_name("test.sqlite3")
if TEST_DB.exists():
    TEST_DB.unlink()
os.environ["DATABASE_URL"] = f"sqlite:///{TEST_DB}"
os.environ["DEV_MODE"] = "true"
os.environ["SIMULATE_DOWNLOAD"] = "true"
os.environ["APP_SECRET"] = "test-only-long-random-secret-not-for-deployment"
os.environ["BOT_TOKEN"] = "test-token:abc"
os.environ["REDIS_URL"] = ""
os.environ["ADMIN_IDS"] = "987654321"
