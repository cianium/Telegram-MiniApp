from fastapi.testclient import TestClient
from app.main import app
from app.database import Job, SessionLocal
from worker.tasks import download_job
from app.security import create_session


def test_health():
    with TestClient(app) as client:
        response = client.get('/api/health')
        assert response.status_code == 200
        assert response.json()['status'] == 'ok'


def test_unauthenticated_requests_blocked():
    with TestClient(app) as client:
        assert client.get('/api/jobs').status_code == 401
        assert client.get('/api/admin/stats').status_code == 401
        assert client.post('/api/jobs', json={'url':'https://youtu.be/test'}).status_code == 401


def test_end_to_end_demo(monkeypatch):
    import app.main as routes
    dispatched = []
    monkeypatch.setattr(routes, 'enqueue_job', lambda job_id: dispatched.append(job_id))
    with TestClient(app) as client:
        auth = client.post('/api/auth/demo')
        assert auth.status_code == 200
        headers = {'Authorization': 'Bearer ' + auth.json()['token']}
        created = client.post('/api/jobs', json={'url': 'https://www.youtube.com/watch?v=abc', 'kind': 'audio'}, headers=headers)
        assert created.status_code == 201, created.text
        job = created.json()
        assert job['status'] == 'queued'
        assert dispatched == [job['id']]
        other_headers = {'Authorization': 'Bearer ' + create_session(88888888)}
        assert client.get(f"/api/jobs/{job['id']}", headers=other_headers).status_code == 404
        assert client.get('/api/admin/stats', headers=headers).status_code == 403
        download_job(job['id'])
        final = client.get(f"/api/jobs/{job['id']}", headers=headers).json()
        assert final['status'] == 'completed'
        assert final['progress'] == 100
        assert 'Demo' in final['message']


def test_cancellation(monkeypatch):
    import app.main as routes
    monkeypatch.setattr(routes, 'enqueue_job', lambda _job_id: None)
    with TestClient(app) as client:
        headers = {'Authorization': 'Bearer ' + client.post('/api/auth/demo').json()['token']}
        job = client.post('/api/jobs', json={'url': 'https://vimeo.com/123456'}, headers=headers).json()
        result = client.delete(f"/api/jobs/{job['id']}", headers=headers)
        assert result.status_code == 200
        assert result.json()['status'] == 'cancelled'
        download_job(job['id'])
        assert client.get(f"/api/jobs/{job['id']}", headers=headers).json()['status'] == 'cancelled'


def test_demo_analyze_without_internet():
    with TestClient(app) as client:
        headers = {'Authorization': 'Bearer ' + client.post('/api/auth/demo').json()['token']}
        response = client.post('/api/media/analyze', json={'url': 'https://youtu.be/abc'}, headers=headers)
        assert response.status_code == 200
        assert response.json()['platform'] == 'YouTube'
        assert response.json()['title'].startswith('Demo')
        invalid = client.post('/api/media/analyze', json={'url':'https://localhost/file'}, headers=headers)
        assert invalid.status_code == 422


def test_clear_history_is_user_scoped(monkeypatch):
    import app.main as routes
    monkeypatch.setattr(routes, 'enqueue_job', lambda _job_id: None)
    with TestClient(app) as client:
        headers = {'Authorization': 'Bearer ' + client.post('/api/auth/demo').json()['token']}
        created = client.post('/api/jobs', json={'url': 'https://vimeo.com/2222'}, headers=headers).json()
        download_job(created['id'])
        other = {'Authorization': 'Bearer ' + create_session(987654321)}
        assert client.delete('/api/history', headers=other).json()['deleted'] == 0
        assert client.get(f"/api/jobs/{created['id']}", headers=headers).status_code == 200
        result = client.delete('/api/history', headers=headers)
        assert result.status_code == 200 and result.json()['deleted'] >= 1
        assert client.get(f"/api/jobs/{created['id']}", headers=headers).status_code == 404
