import hashlib
import hmac
import json
import time
from urllib.parse import urlencode

import pytest
from app.security import verify_telegram_init_data, create_session
from app.media import InvalidMediaURL, validate_media_url


def signed_data(token: str, user_id: int = 76, offset: int = 0):
    raw = {"auth_date": str(int(time.time()) + offset), "user": json.dumps({"id": user_id, "first_name": "Tester", "username": "test"})}
    signing = "\n".join(f"{key}={value}" for key, value in sorted(raw.items()))
    secret = hmac.new(b"WebAppData", token.encode(), hashlib.sha256).digest()
    raw["hash"] = hmac.new(secret, signing.encode(), hashlib.sha256).hexdigest()
    return urlencode(raw)


def test_good_telegram_signature():
    profile = verify_telegram_init_data(signed_data("test-token:abc", user_id=5123456789), "test-token:abc")
    assert profile["id"] == 5123456789 and profile["username"] == "test"


def test_bad_telegram_signature():
    with pytest.raises(ValueError):
        verify_telegram_init_data(signed_data("test-token:abc"), "wrong-token")


def test_expired_and_future_auth():
    for seconds in [-100000, 10000]:
        with pytest.raises(ValueError):
            verify_telegram_init_data(signed_data("test-token:abc", offset=seconds), "test-token:abc")


def test_duplicate_auth_field_rejected():
    with pytest.raises(ValueError, match="Duplicate"):
        verify_telegram_init_data(signed_data("test-token:abc") + "&user=%7B%7D", "test-token:abc")

@pytest.mark.parametrize("url", [
    "http://youtube.com/watch?v=x",
    "https://127.0.0.1:443/private",
    "https://youtube.com.evil.example/watch?v=x",
    "https://localhost/private",
    "https://youtube.com:8080/watch?v=x",
    "https://youtube.com/redirect?q=abc",
    "https://youtube.com/watch?next=https://localhost",
    "file:///etc/passwd",
])
def test_bad_urls_rejected(url):
    with pytest.raises(InvalidMediaURL):
        validate_media_url(url)


def test_supported_domain():
    assert validate_media_url("https://www.youtube.com/watch?v=abc")[1] == "YouTube"
    assert validate_media_url("https://soundcloud.com/artist/track")[1] == "SoundCloud"
