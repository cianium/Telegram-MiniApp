"""Offline contract tests for safe music search and explicit artist consent."""
from dataclasses import replace

from fastapi.testclient import TestClient

from app import main, music
from app.database import SessionLocal, Job
from app.security import create_session
from worker.tasks import download_job


MOCK_DOWNLOAD = "https://prod-1.storage.jamendo.com/download/track/23456/mp32/"
TRACK = {
    "id": "23456",
    "name": "Artist-authorized test track",
    "artist_name": "Test artist",
    "album_name": "Test album",
    "duration": "155",
    "image": "https://usercontent.jamendo.com/example.jpg",
    "audio": "https://prod-1.storage.jamendo.com/some-preview.mp3",
    "audiodownload": MOCK_DOWNLOAD,
    "audiodownload_allowed": True,
    "license_ccurl": "https://creativecommons.org/licenses/by/4.0/",
}


def auth(client):
    result = client.post("/api/auth/demo")
    assert result.status_code == 200
    return {"Authorization": "Bearer " + result.json()["token"]}


def test_music_routes_require_login():
    with TestClient(main.app) as client:
        assert client.get('/api/music/search?q=hello').status_code == 401
        assert client.post('/api/music/jobs', json={"track_id": 23456}).status_code == 401


def test_catalog_search_labels_metadata_only(monkeypatch):
    sample = {"id": "mb:01234567-89ab-cdef-0123-456789abcdef", "title": "Sample song", "artist": "Sample artist", "provider": "MusicBrainz", "downloadable": False}
    monkeypatch.setattr(main, 'search_musicbrainz', lambda q: [sample])
    with TestClient(main.app) as client:
        headers = auth(client)
        result = client.get('/api/music/search?q=sample&source=catalog', headers=headers)
        assert result.status_code == 200
        assert result.json()['results'][0]['downloadable'] is False
        assert result.json()['source'] == 'catalog'
        assert client.get('/api/music/search?q=x', headers=headers).status_code == 422
        assert client.get('/api/music/search?q=hi&source=invalid', headers=headers).status_code == 422


def test_music_download_disabled_until_api_key_configured():
    with TestClient(main.app) as client:
        headers = auth(client)
        search = client.get('/api/music/search?q=ambient&source=downloadable', headers=headers)
        assert search.status_code == 200
        assert search.json()['configured'] is False
        assert client.post('/api/music/jobs', json={"track_id": 23456}, headers=headers).status_code == 503


def test_authorized_music_queue_and_worker_simulation(monkeypatch):
    """A mocked upstream consent response is required to enqueue an audio task."""
    dispatched = []
    monkeypatch.setattr(main, 'settings', replace(main.settings, jamendo_client_id='test-client-id'))
    monkeypatch.setattr(main, 'get_downloadable_track', lambda _track_id: TRACK)
    monkeypatch.setattr(main, 'search_jamendo', lambda _q: [music._normalize_jamendo(TRACK)])
    monkeypatch.setattr(main, 'enqueue_job', lambda job_id: dispatched.append(job_id))
    with TestClient(main.app) as client:
        headers = auth(client)
        found = client.get('/api/music/search?q=artist&source=downloadable', headers=headers)
        assert found.status_code == 200
        assert found.json()['results'][0]['downloadable'] is True
        created = client.post('/api/music/jobs', json={"track_id": 23456}, headers=headers)
        assert created.status_code == 201, created.text
        job = created.json()
        assert dispatched == [job['id']]
        assert job['platform'] == 'Jamendo'
        assert job['kind'] == 'audio'
        with SessionLocal() as db:
            stored = db.get(Job, job['id'])
            assert stored.url == 'https://www.jamendo.com/track/23456'
        stranger = {"Authorization": "Bearer " + create_session(987654322)}
        assert client.get('/api/jobs/' + job['id'], headers=stranger).status_code == 404
        # SIMULATE_DOWNLOAD is on: no external audio file is fetched/sent.
        download_job(job['id'])
        assert client.get('/api/jobs/' + job['id'], headers=headers).json()['status'] == 'completed'


def test_artist_can_refuse_download(monkeypatch):
    monkeypatch.setattr(main, 'settings', replace(main.settings, jamendo_client_id='test-client-id'))
    def blocked(track_id):
        raise music.TrackNotDownloadable('Artist did not authorize downloads')
    monkeypatch.setattr(main, 'get_downloadable_track', blocked)
    with TestClient(main.app) as client:
        headers = auth(client)
        result = client.post('/api/music/jobs', json={"track_id": 23456}, headers=headers)
        assert result.status_code == 422
        assert client.post('/api/music/jobs', json={"track_id": -1}, headers=headers).status_code == 422


def test_download_requires_artist_consent_and_trusted_host():
    assert music.is_allowed_audio_url(MOCK_DOWNLOAD)
    for url in [
        'http://prod-1.storage.jamendo.com/f.mp3',
        'https://localhost/download.mp3',
        'https://prod-1.storage.jamendo.com.evil.com/track.mp3',
        'https://127.0.0.1/track.mp3',
        'https://user:password@prod-1.storage.jamendo.com/a.mp3',
        'https://prod-1.storage.jamendo.com:8080/download.mp3',
    ]:
        assert music.is_allowed_audio_url(url) is False
    assert music._normalize_jamendo({**TRACK, "audiodownload_allowed": False})['downloadable'] is False
    assert music._normalize_jamendo({**TRACK, "audiodownload": "https://127.0.0.1/steal"})['downloadable'] is False


def test_downloadable_track_validation(monkeypatch):
    monkeypatch.setattr(music, '_jamendo_request', lambda _params: [{**TRACK, 'audiodownload_allowed': False}])
    try:
        music.get_downloadable_track(23456)
        assert False, 'Expected artist consent exception'
    except music.TrackNotDownloadable:
        pass
    monkeypatch.setattr(music, '_jamendo_request', lambda _params: [TRACK])
    assert music.get_downloadable_track(23456)['id'] == '23456'


def test_audio_stream_stops_oversized_file(monkeypatch, tmp_path):
    """A provider must not stream an arbitrarily huge file to our VPS."""
    import httpx
    original_client = httpx.Client
    def fake_client(*args, **kwargs):
        return original_client(transport=httpx.MockTransport(
            lambda request: httpx.Response(200, headers={'content-type': 'audio/mpeg'},
                                           content=b'MP3' * 100)), **kwargs)
    monkeypatch.setattr(music.httpx, 'Client', fake_client)
    from pytest import raises
    with raises(music.MusicServiceError, match='size limit'):
        music.download_jamendo_file(TRACK, tmp_path / 'song.mp3', max_bytes=16)


def test_audio_stream_rejects_untrusted_redirect(monkeypatch, tmp_path):
    import httpx
    original_client = httpx.Client
    def fake_client(*args, **kwargs):
        return original_client(transport=httpx.MockTransport(
            lambda request: httpx.Response(302, headers={'location': 'https://127.0.0.1/private'})), **kwargs)
    monkeypatch.setattr(music.httpx, 'Client', fake_client)
    from pytest import raises
    with raises(music.MusicServiceError, match='Unsafe audio source'):
        music.download_jamendo_file(TRACK, tmp_path / 'song.mp3', max_bytes=500)


def test_audio_stream_writes_authorized_mp3(monkeypatch, tmp_path):
    import httpx
    original_client = httpx.Client
    def fake_client(*args, **kwargs):
        return original_client(transport=httpx.MockTransport(
            lambda request: httpx.Response(200, headers={'content-type': 'audio/mpeg'},
                                           content=b'SIMULATED-MP3-BYTES')), **kwargs)
    monkeypatch.setattr(music.httpx, 'Client', fake_client)
    path = tmp_path / 'song.mp3'
    music.download_jamendo_file(TRACK, path, max_bytes=128)
    assert path.read_bytes() == b'SIMULATED-MP3-BYTES'
