"""Telegram bot that launches the Mini App. Run separately from the API."""
import logging
from telegram import InlineKeyboardButton, InlineKeyboardMarkup, Update, WebAppInfo
from telegram.ext import Application, CommandHandler, ContextTypes, MessageHandler, filters
from app.config import get_settings

logging.basicConfig(level=logging.INFO)


async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    s = get_settings()
    if s.webapp_url.startswith("https://"):
        kb = InlineKeyboardMarkup([[InlineKeyboardButton("Open Tg DownBot", web_app=WebAppInfo(url=s.webapp_url))]])
        await update.message.reply_text("Paste a public media URL inside the Mini App. Only download content you own or have permission to save.", reply_markup=kb)
    else:
        await update.message.reply_text("Tg DownBot is ready. Configure the HTTPS WEBAPP_URL to open the Mini App from Telegram.")


async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("Open /start, launch the app and paste a public, permitted media link. Use History to view jobs.")


async def link_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await start(update, context)


if __name__ == "__main__":
    config = get_settings()
    if not config.bot_token:
        raise SystemExit("BOT_TOKEN is missing")
    application = Application.builder().token(config.bot_token).build()
    application.add_handler(CommandHandler("start", start))
    application.add_handler(CommandHandler("help", help_command))
    application.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, link_message))
    application.run_polling()
