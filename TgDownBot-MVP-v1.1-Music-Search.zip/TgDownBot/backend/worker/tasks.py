"""Run isolated download tasks and deliver files via Telegram Bot API."""
from pathlib import Path
from time import monotonic
import logging
import shutil

import httpx

from app.config import get_settings
from app.database import Job, SessionLocal, init_db
from app.media import validate_media_url
from app.music import JAMENDO_TRACK_RE, get_downloadable_track, download_jamendo_file

logger = logging.getLogger("tgdownbot.worker")


class Cancelled(Exception):
    pass


def update_job(job_id: str, **changes):
    with SessionLocal() as db:
        job = db.get(Job, job_id)
        if not job:
            raise ValueError("Job missing")
        for key, value in changes.items():
            setattr(job, key, value)
        db.commit()
        return job.cancel_requested


def ensure_not_cancelled(job_id):
    with SessionLocal() as db:
        job = db.get(Job, job_id)
        if job is None or job.cancel_requested or job.status == "cancelled":
            raise Cancelled("Download cancelled")


def send_file(file_path: Path, user_id: int, audio_title: str = "", audio_artist: str = ""):
    s = get_settings()
    if not s.bot_token:
        raise RuntimeError("BOT_TOKEN missing; cannot send file to Telegram")
    audio = file_path.suffix.lower() == ".mp3"
    method, field = ("sendAudio", "audio") if audio else ("sendDocument", "document")
    url = f"{s.bot_api_base.rstrip('/')}/bot{s.bot_token}/{method}"
    with file_path.open("rb") as handle:
        with httpx.Client(timeout=httpx.Timeout(180, connect=15)) as client:
            form = {"chat_id": str(user_id), "caption": "Delivered by Tg DownBot"}
            if audio and audio_title:
                form["title"] = audio_title
            if audio and audio_artist:
                form["performer"] = audio_artist
            reply = client.post(url, data=form,
                                files={field: (file_path.name, handle, "audio/mpeg" if audio else "application/octet-stream")})
    if not reply.is_success or not reply.json().get("ok"):
        raise RuntimeError("Telegram rejected the file. Start the bot in a private chat and retry")


def download_job(job_id: str):
    s = get_settings()
    init_db()
    folder = Path(s.download_dir).resolve() / job_id
    last_progress = 0.0
    try:
        ensure_not_cancelled(job_id)
        with SessionLocal() as db:
            job = db.get(Job, job_id)
            if job is None:
                return
            user_id, url, kind, quality, platform = job.user_id, job.url, job.kind, job.quality, job.platform
        jamendo_id = None
        if platform == "Jamendo":
            match = JAMENDO_TRACK_RE.fullmatch(url)
            if not match or kind != "audio":
                raise ValueError("Invalid music job")
            jamendo_id = int(match.group(1))
        else:
            validate_media_url(url)  # Never process arbitrary URLs from job storage.
        folder.mkdir(parents=True, exist_ok=True)
        update_job(job_id, status="downloading", progress=1, message="Preparing media")
        if s.simulate_download:
            # Use a harmless local fixture to verify queue, UI, auth and status handling offline.
            fixture = folder / "demo.txt"
            fixture.write_text("Tg DownBot demo download completed. No media was fetched.\n", encoding="utf-8")
            update_job(job_id, progress=100, status="completed", message="Demo complete (no file sent)")
            return

        def ensure_cancelled():
            with SessionLocal() as db:
                current = db.get(Job, job_id)
                return not current or current.cancel_requested

        if jamendo_id is not None:
            # The server re-checks artist permission immediately before downloading.
            track = get_downloadable_track(jamendo_id)
            result_path = folder / "music.mp3"
            update_job(job_id, progress=12, message="Downloading artist-approved music")
            download_jamendo_file(track, result_path, s.max_media_mb * 1024 * 1024, is_cancelled=ensure_cancelled)
        else:
            _download_with_yt_dlp(job_id, url, kind, quality, folder, s, ensure_cancelled)

        ensure_not_cancelled(job_id)
        valid = [p for p in folder.iterdir() if p.is_file() and p.suffix not in {".part", ".ytdl", ".json"}]
        if not valid:
            raise RuntimeError("No downloadable media file was produced")
        result = max(valid, key=lambda p: p.stat().st_size)
        if result.stat().st_size > s.max_media_mb * 1024 * 1024:
            raise RuntimeError("File exceeds Telegram size limit. Select a smaller quality")
        update_job(job_id, status="sending", progress=98, message="Sending file to Telegram")
        send_file(result, user_id,
                  audio_title=str(track.get("name") or "")[:60] if jamendo_id is not None else "",
                  audio_artist=str(track.get("artist_name") or "")[:60] if jamendo_id is not None else "")
        update_job(job_id, status="completed", progress=100, message="File delivered in your Telegram chat")
    except Cancelled:
        update_job(job_id, status="cancelled", message="Cancelled", progress=0)
    except Exception as exc:
        with SessionLocal() as db:
            pending = db.get(Job, job_id)
            cancelled = pending is None or pending.cancel_requested
        if cancelled:
            update_job(job_id, status="cancelled", message="Cancelled", progress=0)
            return
        logger.exception("Download job %s failed", job_id)
        err = str(exc)
        if "BOT_TOKEN missing" in err:
            public_error = "Bot not configured. Add BOT_TOKEN before real downloads"
        elif "Telegram rejected" in err:
            public_error = "Open the bot, press Start and retry"
        elif "size" in err.lower() or "exceeds" in err.lower():
            public_error = "Media is too large. Choose a smaller quality"
        else:
            public_error = "Media could not be processed. Check availability and supported sources"
        update_job(job_id, status="failed", error=public_error, message="Download failed")
    finally:
        shutil.rmtree(folder, ignore_errors=True)


def _download_with_yt_dlp(job_id, url, kind, quality, folder, s, ensure_cancelled):
    import yt_dlp
    last_progress = 0.0

    def progress_hook(data):
        nonlocal last_progress
        if data.get("status") != "downloading":
            return
        now = monotonic()
        if now - last_progress < 1.4:
            return
        last_progress = now
        total = data.get("total_bytes") or data.get("total_bytes_estimate") or 0
        current = data.get("downloaded_bytes") or 0
        percentage = min(95, round(current / total * 90, 1)) if total else 5
        if current > s.max_media_mb * 1024 * 1024:
            raise RuntimeError("File exceeds Telegram upload allowance")
        if ensure_cancelled():
            raise Cancelled("Download cancelled")
        update_job(job_id, progress=percentage, message="Downloading")

    format_setting = "bestaudio/best" if kind == "audio" else (
        "bestvideo+bestaudio/best" if quality == "best" else f"bestvideo[height<={quality}]+bestaudio/best[height<={quality}]/best"
    )
    options = {
        "format": format_setting,
        "outtmpl": str(folder / "media.%(ext)s"),
        "noplaylist": True,
        "js_runtimes": {"node": {}},
        "playlistend": 1,
        "ignoreerrors": False,
        "quiet": True,
        "no_warnings": True,
        "restrictfilenames": True,
        "socket_timeout": 20,
        "retries": 2,
        "fragment_retries": 2,
        "max_filesize": s.max_media_mb * 1024 * 1024,
        "progress_hooks": [progress_hook],
        "postprocessors": ([{"key": "FFmpegExtractAudio", "preferredcodec": "mp3", "preferredquality": "192"}] if kind == "audio" else []),
        "merge_output_format": "mp4" if kind == "video" else None,
    }
    with yt_dlp.YoutubeDL(options) as ydl:
        ydl.download([url])
