"""Start background RQ worker in production."""
import logging
from redis import Redis
from rq import Worker, Queue
from app.config import get_settings, verify_configuration
from app.database import init_db

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    verify_configuration()
    init_db()
    if not get_settings().redis_url:
        raise SystemExit("Set REDIS_URL to start the production worker")
    connection = Redis.from_url(get_settings().redis_url)
    Worker([Queue("downloads", connection=connection)], connection=connection).work()
