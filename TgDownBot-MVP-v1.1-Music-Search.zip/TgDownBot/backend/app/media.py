"""Provider allowlist and metadata extraction, without bypassing access controls."""
from urllib.parse import urlsplit, parse_qs
import ipaddress

ALLOWED = {
    "YouTube": ("youtube.com", "youtu.be", "youtube-nocookie.com"),
    "Instagram": ("instagram.com",),
    "SoundCloud": ("soundcloud.com",),
    "TikTok": ("tiktok.com",),
    "Vimeo": ("vimeo.com",),
}


class InvalidMediaURL(ValueError):
    pass


def validate_media_url(value: str) -> tuple[str, str]:
    if not isinstance(value, str) or len(value) > 2048:
        raise InvalidMediaURL("Link is too long")
    try:
        parts = urlsplit(value.strip())
        host = (parts.hostname or "").lower().rstrip(".")
        port = parts.port
    except ValueError as exc:
        raise InvalidMediaURL("Invalid URL") from exc
    if parts.scheme != "https" or not host or parts.username or parts.password or port not in (None, 443):
        raise InvalidMediaURL("Only public HTTPS links are supported")
    try:
        ipaddress.ip_address(host)
        raise InvalidMediaURL("Direct IP addresses are not allowed")
    except ValueError as exc:
        if isinstance(exc, InvalidMediaURL):
            raise
    # Avoid provider-hosted redirect endpoints that can target arbitrary addresses.
    if any(seg in parts.path.lower() for seg in ("/redirect", "/away", "/outbound")):
        raise InvalidMediaURL("Redirect links are not supported")
    if {x.lower() for x in parse_qs(parts.query)} & {"url", "redirect", "redirect_url", "next", "target"}:
        raise InvalidMediaURL("Redirect parameters are not supported")
    for provider, domains in ALLOWED.items():
        if any(host == domain or host.endswith("." + domain) for domain in domains):
            return value.strip(), provider
    raise InvalidMediaURL("Unsupported platform. Try a public YouTube, Instagram, SoundCloud, TikTok or Vimeo link")


def extract_metadata(url: str) -> dict:
    import yt_dlp
    validated, platform = validate_media_url(url)
    options = {
        "quiet": True,
        "no_warnings": True,
        "noplaylist": True,
        "js_runtimes": {"node": {}},
        "extract_flat": False,
        "skip_download": True,
        "socket_timeout": 12,
        "retries": 1,
        "playlistend": 1,
        "ignoreerrors": False,
    }
    with yt_dlp.YoutubeDL(options) as client:
        info = client.extract_info(validated, download=False)
    if not info or (info.get("entries") is not None):
        raise ValueError("Please provide a single public media item, not a playlist")
    if info.get("is_live") or info.get("live_status") in {"is_live", "is_upcoming"}:
        raise ValueError("Live streams are not supported")
    if info.get("_has_drm"):
        raise ValueError("Protected media is not supported")
    heights = {int(f["height"]) for f in info.get("formats", []) if f.get("height") and f.get("vcodec") != "none"}
    qualities = ["best"] + [str(h) for h in (1080, 720, 480, 360) if h in heights]
    return {
        "title": str(info.get("title") or "Untitled")[:300],
        "platform": platform,
        "thumbnail": str(info.get("thumbnail") or "")[:1500],
        "duration": info.get("duration") if isinstance(info.get("duration"), (float, int)) else None,
        "qualities": qualities,
        "audio_available": True,
    }
