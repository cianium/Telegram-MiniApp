"""License-aware music discovery: broad metadata + artist-authorized downloads.

MusicBrainz is a metadata catalog, never a download provider. Jamendo exposes
per-track download consent; the server must re-check that consent before queueing
and again in the worker immediately before transferring the file.
"""
from __future__ import annotations

import asyncio
import re
import threading
import time
from typing import Any
from urllib.parse import urljoin, urlsplit

import httpx

from .config import get_settings

MUSICBRAINZ_URL = "https://musicbrainz.org/ws/2/recording/"
JAMENDO_URL = "https://api.jamendo.com/v3.0/tracks/"
JAMENDO_TRACK_RE = re.compile(r"^https://www\.jamendo\.com/track/([1-9][0-9]{0,11})$")
# Only Jamendo's own approved media hosts may serve download bytes. No IP URLs,
# localhost, private-address hosts, or third-party redirect targets are accepted.
ALLOWED_AUDIO_HOSTS = ("storage.jamendo.com",)

_MB_LOCK = threading.Lock()
_MB_LAST = 0.0


class MusicServiceError(Exception):
    """A safe, user-facing upstream failure."""


class TrackNotDownloadable(MusicServiceError):
    """An artist disabled downloading, or the track is unavailable."""


def _get_json(url: str, params: dict[str, Any], *, headers: dict[str, str] | None = None) -> dict:
    try:
        with httpx.Client(timeout=httpx.Timeout(12.0, connect=5.0), follow_redirects=False) as client:
            response = client.get(url, params=params, headers=headers)
            response.raise_for_status()
            data = response.json()
        if not isinstance(data, dict):
            raise MusicServiceError("Music provider returned an invalid response")
        return data
    except (httpx.HTTPError, ValueError) as exc:
        raise MusicServiceError("Music search provider is temporarily unavailable") from exc


def search_musicbrainz(query: str) -> list[dict]:
    """Public recordings metadata; never label these as downloadable."""
    global _MB_LAST
    # Respect MusicBrainz's one-request-per-second policy per API instance.
    # A multi-instance production deployment needs a shared Redis gate as well.
    with _MB_LOCK:
        delay = 1.1 - (time.monotonic() - _MB_LAST)
        if delay > 0:
            time.sleep(delay)
        _MB_LAST = time.monotonic()
        data = _get_json(MUSICBRAINZ_URL, {"query": query, "fmt": "json", "limit": 20},
                         headers={"User-Agent": "TgDownBot/1.1 (music discovery; https://github.com/cianium)",
                                  "Accept": "application/json"})
    output = []
    for item in data.get("recordings", []):
        identity = str(item.get("id") or "")
        if not re.fullmatch(r"[0-9a-fA-F-]{36}", identity):
            continue
        artists = ", ".join(a.get("name", "") for a in item.get("artist-credit", []) if isinstance(a, dict))
        releases = item.get("releases") or []
        album = str(releases[0].get("title") or "") if releases else ""
        output.append({
            "id": f"mb:{identity}", "title": str(item.get("title") or "Unknown")[:200],
            "artist": artists[:200], "album": album[:200], "provider": "MusicBrainz",
            "duration": round(item["length"] / 1000) if isinstance(item.get("length"), (int, float)) else None,
            "cover": "", "preview": "", "downloadable": False, "license_url": "",
            "source_url": f"https://musicbrainz.org/recording/{identity}",
        })
    return output


def _jamendo_request(params: dict[str, Any]) -> list[dict]:
    key = get_settings().jamendo_client_id
    if not key:
        raise MusicServiceError("JAMENDO_CLIENT_ID is not configured")
    data = _get_json(JAMENDO_URL, {"client_id": key, "format": "json", "audiodlformat": "mp32", **params})
    if data.get("headers", {}).get("status") == "failed":
        raise MusicServiceError("Jamendo rejected the request")
    results = data.get("results")
    if not isinstance(results, list):
        raise MusicServiceError("Jamendo returned an invalid track list")
    return results


def is_allowed_audio_url(raw_url: str) -> bool:
    try:
        parsed = urlsplit(raw_url)
        host = (parsed.hostname or "").lower().rstrip(".")
        return (parsed.scheme == "https" and parsed.port in (None, 443)
                and not parsed.username and not parsed.password
                and any(host == base or host.endswith("." + base) for base in ALLOWED_AUDIO_HOSTS))
    except ValueError:
        return False


def _track_allowed(track: dict) -> bool:
    return (track.get("audiodownload_allowed") is True
            and bool(track.get("audiodownload"))
            and is_allowed_audio_url(str(track.get("audiodownload") or "")))


def _normalize_jamendo(track: dict) -> dict:
    track_id = str(track.get("id", ""))
    if not track_id.isdecimal() or int(track_id) <= 0:
        raise MusicServiceError("Jamendo returned an invalid track ID")
    return {
        "id": f"jam:{track_id}", "title": str(track.get("name") or "Unknown")[:200],
        "artist": str(track.get("artist_name") or "")[:200],
        "album": str(track.get("album_name") or "")[:200],
        "provider": "Jamendo",
        "duration": int(track["duration"]) if str(track.get("duration", "")).isdigit() else None,
        "cover": str(track.get("image") or "")[:1600],
        "preview": str(track.get("audio") or "")[:1600],
        "downloadable": _track_allowed(track),
        "license_url": str(track.get("license_ccurl") or "")[:512],
        "source_url": f"https://www.jamendo.com/track/{track_id}",
    }


def search_jamendo(query: str) -> list[dict]:
    return [_normalize_jamendo(item) for item in _jamendo_request({"search": query, "limit": 25})]


def get_downloadable_track(track_id: int) -> dict:
    if track_id <= 0 or track_id > 999_999_999_999:
        raise TrackNotDownloadable("Invalid music track identifier")
    results = _jamendo_request({"id": track_id, "limit": 1})
    if not results or str(results[0].get("id")) != str(track_id):
        raise TrackNotDownloadable("Track not available")
    track = results[0]
    if not _track_allowed(track):
        raise TrackNotDownloadable("This artist has not enabled downloads for this track")
    return track


def download_jamendo_file(track: dict, destination, max_bytes: int, is_cancelled=None) -> None:
    """Stream artist-approved MP3 with a hard byte cap and strict redirect allowlist."""
    if not _track_allowed(track):
        raise TrackNotDownloadable("Artist permission no longer allows download")
    url = str(track["audiodownload"])
    with httpx.Client(timeout=httpx.Timeout(60.0, connect=8.0), follow_redirects=False, trust_env=False) as client:
        for _ in range(5):
            if not is_allowed_audio_url(url):
                raise MusicServiceError("Unsafe audio source")
            with client.stream("GET", url, headers={"Accept": "audio/*,application/octet-stream"}) as response:
                if response.status_code in (301, 302, 303, 307, 308):
                    url = urljoin(url, response.headers.get("location", ""))
                    continue
                response.raise_for_status()
                if response.headers.get("content-type", "").lower().startswith("text/html"):
                    raise MusicServiceError("Provider returned a page instead of an audio file")
                declared = response.headers.get("content-length")
                if declared and int(declared) > max_bytes:
                    raise MusicServiceError("Audio file exceeds Telegram size limit")
                downloaded = 0
                with open(destination, "wb") as output:
                    for chunk in response.iter_bytes(chunk_size=64 * 1024):
                        if is_cancelled and is_cancelled():
                            raise MusicServiceError("Music job cancelled")
                        downloaded += len(chunk)
                        if downloaded > max_bytes:
                            raise MusicServiceError("Audio file exceeds Telegram size limit")
                        output.write(chunk)
                if downloaded == 0:
                    raise MusicServiceError("Empty audio file")
                return
    raise MusicServiceError("Too many audio redirects")
