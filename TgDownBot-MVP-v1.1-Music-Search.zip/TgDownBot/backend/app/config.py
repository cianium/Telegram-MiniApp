"""Environment configuration. No secrets are committed to the repository."""
from dataclasses import dataclass
from functools import lru_cache
import os

from dotenv import load_dotenv

load_dotenv()


def flag(name: str, default: str = "false") -> bool:
    return os.getenv(name, default).strip().lower() in {"1", "true", "yes"}


@dataclass(frozen=True)
class Settings:
    database_url: str
    bot_token: str
    app_secret: str
    dev_mode: bool
    simulate_download: bool
    redis_url: str
    max_media_mb: int
    max_jobs_per_day: int
    webapp_url: str
    bot_api_base: str
    allowed_origins: tuple[str, ...]
    admin_ids: frozenset[int]
    download_dir: str
    jamendo_client_id: str


@lru_cache

def get_settings() -> Settings:
    admin_ids = frozenset(int(x.strip()) for x in os.getenv("ADMIN_IDS", "").split(",") if x.strip().isdigit())
    return Settings(
        database_url=os.getenv("DATABASE_URL", "sqlite:///./tgdownbot.db"),
        bot_token=os.getenv("BOT_TOKEN", ""),
        app_secret=os.getenv("APP_SECRET", "change-me-in-production"),
        dev_mode=flag("DEV_MODE", "true"),
        simulate_download=flag("SIMULATE_DOWNLOAD", "false"),
        redis_url=os.getenv("REDIS_URL", ""),
        max_media_mb=int(os.getenv("MAX_MEDIA_MB", "45")),
        max_jobs_per_day=int(os.getenv("MAX_JOBS_PER_DAY", "10")),
        webapp_url=os.getenv("WEBAPP_URL", ""),
        bot_api_base=os.getenv("BOT_API_BASE", "https://api.telegram.org"),
        allowed_origins=tuple(x.strip() for x in os.getenv("ALLOWED_ORIGINS", "http://localhost:5173,http://127.0.0.1:5173").split(",") if x.strip()),
        admin_ids=admin_ids,
        download_dir=os.getenv("DOWNLOAD_DIR", "./downloads"),
        jamendo_client_id=os.getenv("JAMENDO_CLIENT_ID", "").strip(),
    )


def verify_configuration() -> None:
    s = get_settings()
    if not s.dev_mode and (not s.bot_token or s.app_secret == "change-me-in-production" or len(s.app_secret) < 32):
        raise RuntimeError("Production requires BOT_TOKEN and strong APP_SECRET (32+ characters)")
    if not s.dev_mode and not s.redis_url:
        raise RuntimeError("Production requires REDIS_URL for a durable background queue")
    if s.max_media_mb < 1 or s.max_media_mb > 49:
        raise RuntimeError("MAX_MEDIA_MB must be between 1 and 49 for the public Bot API")
