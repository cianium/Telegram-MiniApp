"""Redis-backed per-user rate limit for metadata analysis.
Fail closed in production if Redis becomes unavailable.
"""
import threading
import time
from fastapi import HTTPException
from .config import get_settings

_local: dict[tuple[int, int], int] = {}
_lock = threading.Lock()


def check_analysis_quota(user_id: int, max_requests: int = 20, window_seconds: int = 600) -> None:
    settings = get_settings()
    bucket = int(time.time() // window_seconds)
    if settings.redis_url:
        try:
            from redis import Redis
            redis = Redis.from_url(settings.redis_url, socket_timeout=2)
            key = f"tgdown:analysis:{user_id}:{bucket}"
            with redis.pipeline(transaction=True) as pipe:
                pipe.incr(key)
                pipe.expire(key, window_seconds + 5)
                count, _ = pipe.execute()
        except Exception as exc:
            raise HTTPException(503, "Rate-limit service unavailable") from exc
    elif settings.dev_mode:
        with _lock:
            key_local = (user_id, bucket)
            count = _local.get(key_local, 0) + 1
            _local[key_local] = count
            # Bound process-local storage during long development sessions.
            if len(_local) > 2000:
                for key in list(_local):
                    if key[1] < bucket - 1:
                        _local.pop(key, None)
    else:
        raise HTTPException(503, "Rate-limit service unavailable")
    if count > max_requests:
        raise HTTPException(429, "Too many previews. Please wait a few minutes")
