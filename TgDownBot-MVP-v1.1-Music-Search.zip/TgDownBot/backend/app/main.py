"""HTTP API for Tg DownBot Mini App."""
from datetime import datetime, timedelta, timezone
import asyncio
import logging
from typing import Literal

from fastapi import Depends, FastAPI, HTTPException, Request
from contextlib import asynccontextmanager
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from .config import get_settings, verify_configuration
from .database import Job, User, get_db, init_db
from .media import InvalidMediaURL, extract_metadata, validate_media_url
from .music import MusicServiceError, TrackNotDownloadable, search_musicbrainz, search_jamendo, get_downloadable_track
from .limiter import check_analysis_quota
from .queue import enqueue_job
from .security import create_session, require_user, verify_telegram_init_data

logger = logging.getLogger("tgdownbot")
settings = get_settings()

@asynccontextmanager
async def lifespan(application: FastAPI):
    verify_configuration()
    init_db()
    yield

app = FastAPI(title="Tg DownBot API", version="1.0.0", docs_url="/api/docs" if settings.dev_mode else None, redoc_url=None, lifespan=lifespan)
app.add_middleware(CORSMiddleware, allow_origins=list(settings.allowed_origins), allow_credentials=False, allow_methods=["GET", "POST", "DELETE"], allow_headers=["Authorization", "Content-Type"])


class AuthInput(BaseModel):
    init_data: str = Field(max_length=16384)


class URLInput(BaseModel):
    url: str = Field(min_length=10, max_length=2048)


class MusicJobInput(BaseModel):
    track_id: int = Field(gt=0, le=999_999_999_999)


class JobInput(URLInput):
    kind: Literal["video", "audio"] = "video"
    quality: Literal["best", "1080", "720", "480", "360"] = "best"


def ensure_user(db: Session, profile: dict):
    user = db.get(User, profile["id"])
    if user is None:
        user = User(**profile)
        db.add(user)
    else:
        user.first_name = profile["first_name"]
        user.username = profile["username"]
    db.commit()


def output_job(job: Job) -> dict:
    return {
        "id": job.id, "title": job.title, "platform": job.platform,
        "kind": job.kind, "quality": job.quality, "status": job.status,
        "progress": round(job.progress, 1), "error": job.error, "message": job.message,
        "created_at": job.created_at.isoformat() if job.created_at else "",
    }


@app.get("/api/health")
def health():
    return {"status": "ok", "mode": "development" if settings.dev_mode else "production"}


@app.post("/api/auth/telegram")
def telegram_auth(payload: AuthInput, db: Session = Depends(get_db)):
    try:
        profile = verify_telegram_init_data(payload.init_data, settings.bot_token)
    except ValueError as exc:
        raise HTTPException(status_code=401, detail=str(exc)) from exc
    ensure_user(db, profile)
    return {"token": create_session(profile["id"]), "profile": profile, "is_admin": profile["id"] in settings.admin_ids}


@app.post("/api/auth/demo")
def demo_auth(request: Request, db: Session = Depends(get_db)):
    # Prevent accidentally allowing untrusted Internet clients into demo mode.
    if not settings.dev_mode or request.client is None or request.client.host not in {"127.0.0.1", "::1", "localhost", "testclient"}:
        raise HTTPException(status_code=404, detail="Not found")
    profile = {"id": 123456789, "first_name": "Demo User", "username": "demo"}
    ensure_user(db, profile)
    return {"token": create_session(profile["id"]), "profile": profile, "is_admin": False}


@app.get("/api/me")
def me(user_id: int = Depends(require_user), db: Session = Depends(get_db)):
    profile = db.get(User, user_id)
    if not profile:
        raise HTTPException(401, "Unknown user")
    return {"id": profile.id, "first_name": profile.first_name, "username": profile.username, "is_admin": user_id in settings.admin_ids}


@app.post("/api/media/analyze")
async def analyze(payload: URLInput, user_id: int = Depends(require_user)):
    check_analysis_quota(user_id)
    try:
        clean, platform = validate_media_url(payload.url)
        if settings.simulate_download:
            return {"title": "Demo preview — no external download", "platform": platform,
                    "thumbnail": "", "duration": 120, "qualities": ["best", "720", "480"],
                    "audio_available": True}
        return await asyncio.wait_for(asyncio.to_thread(extract_metadata, clean), timeout=40)
    except InvalidMediaURL as exc:
        raise HTTPException(422, detail=str(exc)) from exc
    except asyncio.TimeoutError as exc:
        raise HTTPException(504, detail="Metadata request timed out") from exc
    except Exception as exc:
        logger.warning("Metadata extraction failed: %s", type(exc).__name__)
        raise HTTPException(422, detail="Cannot inspect this media. It may be private, unavailable or unsupported") from exc



@app.get("/api/music/search")
async def music_search(
    q: str = "", source: Literal["catalog", "downloadable"] = "catalog",
    user_id: int = Depends(require_user),
):
    query = " ".join(q.split())
    if len(query) < 2 or len(query) > 100:
        raise HTTPException(422, "Search text must be 2–100 characters")
    check_analysis_quota(user_id, max_requests=30)
    if source == "downloadable" and not settings.jamendo_client_id:
        return {"results": [], "configured": False, "source": source,
                "notice": "Configure JAMENDO_CLIENT_ID to enable music downloads"}
    try:
        fn = search_musicbrainz if source == "catalog" else search_jamendo
        results = await asyncio.wait_for(asyncio.to_thread(fn, query), timeout=18)
    except (MusicServiceError, asyncio.TimeoutError):
        raise HTTPException(503, "Music service temporarily unavailable") from None
    return {"results": results, "configured": True, "source": source,
            "notice": "Metadata only; download rights depend on the provider" if source == "catalog" else "Only artist-approved tracks can be downloaded"}


@app.post("/api/music/jobs", status_code=201)
async def music_download_job(
    payload: MusicJobInput,
    user_id: int = Depends(require_user), db: Session = Depends(get_db),
):
    if not settings.jamendo_client_id:
        raise HTTPException(503, "Music downloads require a Jamendo API client ID")
    try:
        track = await asyncio.wait_for(asyncio.to_thread(get_downloadable_track, payload.track_id), timeout=18)
    except TrackNotDownloadable as exc:
        raise HTTPException(422, str(exc)) from exc
    except (MusicServiceError, asyncio.TimeoutError):
        raise HTTPException(503, "Music provider temporarily unavailable") from None
    title = f"{track.get('artist_name') or 'Unknown'} — {track.get('name') or 'Track'}"[:400]
    # No caller-controlled download URL is accepted. The worker resolves this
    # track ID and verifies the artist's permission again before transferring.
    return _create_job_for_user(db, user_id, url=f"https://www.jamendo.com/track/{payload.track_id}",
                                platform="Jamendo", title=title, kind="audio", quality="best")


def _create_job_for_user(db: Session, user_id: int, *, url: str, platform: str,
                         title: str, kind: str, quality: str):
    active = db.scalar(select(func.count()).select_from(Job).where(
        Job.user_id == user_id, Job.status.in_(["queued", "downloading", "sending"])))
    if active >= 1:
        raise HTTPException(429, detail="Complete or cancel your existing job first")
    beginning = datetime.now(timezone.utc) - timedelta(days=1)
    recent = db.scalar(select(func.count()).select_from(Job).where(
        Job.user_id == user_id, Job.created_at >= beginning))
    if recent >= settings.max_jobs_per_day:
        raise HTTPException(429, detail="Daily limit reached; try again tomorrow")
    job = Job(user_id=user_id, url=url, platform=platform, title=title, kind=kind, quality=quality)
    db.add(job)
    db.commit()
    db.refresh(job)
    try:
        enqueue_job(job.id)
    except Exception:
        logger.exception("Queue connection failed")
        job.status = "failed"
        job.error = "Could not start processing; please try again later"
        db.commit()
        raise HTTPException(503, detail="Download queue is unavailable")
    return output_job(job)


@app.post("/api/jobs", status_code=201)
def create_job(payload: JobInput, user_id: int = Depends(require_user), db: Session = Depends(get_db)):
    try:
        clean, platform = validate_media_url(payload.url)
    except InvalidMediaURL as exc:
        raise HTTPException(422, detail=str(exc)) from exc
    if platform == "YouTube" and "list=" in clean:
        raise HTTPException(422, detail="Playlists are not supported")
    return _create_job_for_user(db, user_id, url=clean, platform=platform,
                                title="Media download", kind=payload.kind, quality=payload.quality)



@app.get("/api/jobs")
def history(user_id: int = Depends(require_user), db: Session = Depends(get_db)):
    jobs = db.scalars(select(Job).where(Job.user_id == user_id).order_by(Job.created_at.desc()).limit(30)).all()
    return [output_job(job) for job in jobs]


@app.delete("/api/history")
def clear_history(user_id: int = Depends(require_user), db: Session = Depends(get_db)):
    # Only terminal jobs may be deleted; active jobs need explicit cancellation.
    from sqlalchemy import delete
    outcome = db.execute(delete(Job).where(Job.user_id == user_id, Job.status.in_(["completed", "failed", "cancelled"])))
    db.commit()
    return {"deleted": outcome.rowcount or 0}

@app.get("/api/jobs/{job_id}")
def get_job(job_id: str, user_id: int = Depends(require_user), db: Session = Depends(get_db)):
    job = db.get(Job, job_id)
    if not job or job.user_id != user_id:
        raise HTTPException(404, "Job not found")
    return output_job(job)


@app.delete("/api/jobs/{job_id}")
def cancel_job(job_id: str, user_id: int = Depends(require_user), db: Session = Depends(get_db)):
    job = db.get(Job, job_id)
    if not job or job.user_id != user_id:
        raise HTTPException(404, "Job not found")
    if job.status == "queued":
        job.cancel_requested = True
        job.status = "cancelled"
    elif job.status == "downloading":
        job.cancel_requested = True
        job.message = "Cancellation requested"
    else:
        raise HTTPException(409, "This job cannot be cancelled")
    db.commit()
    return output_job(job)


@app.get("/api/admin/stats")
def admin_stats(user_id: int = Depends(require_user), db: Session = Depends(get_db)):
    if user_id not in settings.admin_ids:
        raise HTTPException(403, "Admin only")
    return {
        "users": db.scalar(select(func.count()).select_from(User)),
        "jobs": db.scalar(select(func.count()).select_from(Job)),
        "completed": db.scalar(select(func.count()).select_from(Job).where(Job.status == "completed")),
        "failed": db.scalar(select(func.count()).select_from(Job).where(Job.status == "failed")),
        "active": db.scalar(select(func.count()).select_from(Job).where(Job.status.in_(["queued", "downloading", "sending"]))),
    }
