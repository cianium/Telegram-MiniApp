"""RQ in production; bounded thread pool in local development only."""
from concurrent.futures import ThreadPoolExecutor
from .config import get_settings

_executor = ThreadPoolExecutor(max_workers=2, thread_name_prefix="tgdown-dev")


def enqueue_job(job_id: str):
    s = get_settings()
    if s.redis_url:
        from redis import Redis
        from rq import Queue
        queue = Queue("downloads", connection=Redis.from_url(s.redis_url))
        queue.enqueue("worker.tasks.download_job", job_id, job_timeout=1200, result_ttl=600, failure_ttl=3600)
    elif s.dev_mode:
        from worker.tasks import download_job
        _executor.submit(download_job, job_id)
    else:
        raise RuntimeError("Background job queue is not configured")
