"""Verify Telegram WebApp initData server-side; sign short-lived API sessions."""
from datetime import datetime, timezone
import hashlib
import hmac
import json
from urllib.parse import parse_qsl

from fastapi import HTTPException, Header
from itsdangerous import BadSignature, SignatureExpired, URLSafeTimedSerializer
from .config import get_settings


def verify_telegram_init_data(raw: str, token: str, max_age: int = 86400) -> dict:
    if not raw or len(raw) > 16384 or not token:
        raise ValueError("Missing Telegram authentication data")
    pairs = parse_qsl(raw, keep_blank_values=True, strict_parsing=True)
    keys = [key for key, _ in pairs]
    if len(keys) != len(set(keys)):
        raise ValueError("Duplicate auth fields")
    data = dict(pairs)
    claimed_hash = data.get("hash", "")
    if len(claimed_hash) != 64:
        raise ValueError("Invalid Telegram signature")
    check_string = "\n".join(f"{key}={value}" for key, value in sorted(pairs) if key not in {"hash", "signature"})
    secret_key = hmac.new(b"WebAppData", token.encode(), hashlib.sha256).digest()
    actual_hash = hmac.new(secret_key, check_string.encode(), hashlib.sha256).hexdigest()
    if not hmac.compare_digest(claimed_hash, actual_hash):
        raise ValueError("Invalid Telegram signature")
    try:
        issued_at = int(data["auth_date"])
        user = json.loads(data["user"])
        user_id = int(user["id"])
    except (ValueError, KeyError, TypeError, json.JSONDecodeError) as exc:
        raise ValueError("Malformed Telegram user data") from exc
    delta = datetime.now(timezone.utc).timestamp() - issued_at
    if not (-60 <= delta <= max_age) or user_id <= 0:
        raise ValueError("Telegram authentication expired")
    return {"id": user_id, "first_name": str(user.get("first_name", ""))[:160], "username": str(user.get("username", ""))[:80]}


def _serializer():
    return URLSafeTimedSerializer(get_settings().app_secret, salt="tgdownbot-api-session-v1")


def create_session(user_id: int) -> str:
    return _serializer().dumps({"uid": user_id})


def require_user(authorization: str = Header(default="")) -> int:
    if not authorization.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="Please sign in via Telegram")
    try:
        payload = _serializer().loads(authorization[7:], max_age=86400)
        user_id = int(payload["uid"])
        if user_id <= 0:
            raise ValueError()
        return user_id
    except (BadSignature, SignatureExpired, ValueError, KeyError, TypeError) as exc:
        raise HTTPException(status_code=401, detail="Session expired; reopen the Mini App") from exc
