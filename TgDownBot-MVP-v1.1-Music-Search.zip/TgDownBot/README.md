# Tg DownBot — Telegram Downloader Mini App (MVP source)

Mobile-first Telegram Mini App + Telegram Bot + FastAPI + Python `yt-dlp` worker.

**State:** Local MVP source with license-aware music search, not deployed. No real Telegram download has been verified yet. Use permitted public media only; extraction can break when platforms change.

## Included

- React/TypeScript Mini App: link entry, thumbnail/metadata preview, video resolution or MP3 option, **Music Search tab (artist / song / album)**, progress/status, recent history, Persian/English, account settings, basic admin stats.
- Telegram bot: `/start`, `/help`, launch button (only with HTTPS WEBAPP_URL).
- FastAPI: Telegram signed auth (HMAC), session tokens, 1 active task/user, 10 tasks/day default, job ownership, cancellation, admin stats.
- Background jobs: local thread worker for development, Redis+RQ for production mode.
- Downloader: yt-dlp with allowed provider domains; Jamendo artist-authorized MP3 (requires an API client ID); FFmpeg for conversions; file size limit 45 MiB; temporary cleanup.
- Dev demo: uses a generated local text file, **no external download or Telegram send**.
- Automated tests and Docker-based deployment scaffolding.

## Quick start for local Ubuntu / Termux (no server purchase)

Requirements: Python 3.12+, **Node 22+** (also used by yt-dlp for modern YouTube support), FFmpeg, Git. Use **two terminal sessions**.

```bash
unzip TgDownBot-MVP-v1.1-Music-Search.zip
cd TgDownBot
cp .env.example .env
# .env starts with DEV_MODE=true and SIMULATE_DOWNLOAD=true
cd backend
python -m venv .venv
source .venv/bin/activate
pip install -r requirements-dev.txt
uvicorn app.main:app --host 127.0.0.1 --port 8000
```

New terminal:

```bash
cd TgDownBot/frontend
npm install
npm run dev
```

Open `http://127.0.0.1:5173` on the **same device**. If using Termux, avoid Python `venv` on shared Android storage; extract the project into Termux `$HOME` first. The UI will authenticate as Demo User and work without Telegram credentials.

The local demo supplies **simulated metadata** on the Analyze screen and creates a harmless text fixture in the worker. You can test the whole UI flow offline. Real media and Bot delivery remain disabled while `SIMULATE_DOWNLOAD=true`.

## Music Search and authorized downloads

The **Music** tab has two explicitly different searches:

1. **Music catalog** — searches [MusicBrainz](https://musicbrainz.org/) by song, artist or album. This is **metadata only**, and cannot supply downloadable music files. Results link to the source page. MusicBrainz limits clients to 1 request/second; this source gates requests in-process and must use a global Redis rate gate before deployment with multiple API replicas.
2. **Downloadable music** — searches [Jamendo](https://www.jamendo.com/) artists' tracks and shows download buttons only when Jamendo returns `audiodownload_allowed=true` and a recognized download URL. The API and Worker re-check the track's permission before queuing and downloading. Only Jamendo-owned approved audio endpoints are followed.

To configure the second search, register your own developer application with [Jamendo's official developer portal](https://developer.jamendo.com/), then set:

```dotenv
JAMENDO_CLIENT_ID=your_own_client_id
```

Do not put this value in frontend code. Restart the API and Worker after setting it. No paid server is needed to implement or locally test the API contract. The **demo mode does not download or send real songs**. To test real MP3 delivery you need an actual bot and a Telegram user ID, and must run the bot and API accordingly.

**Limitations:** No legal source provides unrestricted downloads of every copyrighted song. MusicBrainz provides broad recording discovery, not track files; Jamendo primarily catalogs independent/Creative Commons music. This project does not offer Spotify, Apple Music or unauthorized downloads. Individual Creative Commons license restrictions must still be respected.

## Tests

```bash
cd TgDownBot/backend
source .venv/bin/activate
pytest -q
cd ../frontend
npm run build
```

## Real download tests (on your own machine, later)

1. Create a Telegram bot via `@BotFather`; store token in `.env` as `BOT_TOKEN=...` (never send the token to chat or GitHub).
2. Set `SIMULATE_DOWNLOAD=false`, install FFmpeg and the current yt-dlp runtime dependencies.
3. Run bot in a third terminal: `cd backend && python bot.py`.
4. Send `/start` to the bot in Telegram to permit delivery. Without an HTTPS `WEBAPP_URL`, the Mini App launches only in the browser's localhost demo; an HTTPS endpoint is needed to launch it **inside Telegram**.
5. Real Telegram login and file delivery require manual end-to-end tests; the local demo identity is **not your Telegram ID**, so file delivery from local demo will fail. Do not use demo credentials for real delivery.

## Later production deployment (NOT part of local completion)

- Require HTTPS with a valid public Mini App URL, `DEV_MODE=false`, strong `APP_SECRET`, real `BOT_TOKEN`, `WEBAPP_URL`, and allowed `ALLOWED_ORIGINS`.
- Set `POSTGRES_PASSWORD` in `.env`; `docker compose up --build -d` starts API, Redis, database, worker and bot. This is a deployment scaffold, not production readiness certification.
- Reverse-proxy API and frontend behind TLS, enforce worker network isolation, non-root user/limits, backup strategy, rate limits, observability, and security review before release.
- See [Architecture & Known Limitations](docs/ARCHITECTURE.md) and [Music Search Integration](docs/MUSIC_SEARCH.md).

## Project tree

```text
TgDownBot/
├── frontend/         React + Vite + TypeScript Mini App
├── backend/
│   ├── app/          FastAPI, auth, data model, media, queue
│   ├── worker/       Jobs and delivery
│   ├── tests/        API, auth, URL-security and demo tests
│   ├── bot.py        Telegram bot entry point
│   └── Dockerfile
├── docs/             Architecture, caveats and progress
├── compose.yaml     Deployment scaffold
└── .env.example      Safe configuration template
```
