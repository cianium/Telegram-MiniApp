import { useCallback, useEffect, useState } from 'react'
import { ArrowDownToLine, ArrowLeft, ArrowRight, AudioLines, CheckCircle2, CircleAlert, Clipboard, Clock3, Download, ExternalLink, FileAudio, FileVideo, Globe2, History, Home, Link2, Loader2, Moon, Music2, PlayCircle, RefreshCw, Search, Settings2, ShieldCheck, Sparkles, Square, UserRound, Video, X } from 'lucide-react'
import { api, setToken, type Job, type MediaInfo, type MusicTrack, type Profile } from './api'

type Tab = 'home' | 'music' | 'history' | 'settings'
type WebApp = { initData: string; ready: () => void; expand: () => void; colorScheme?: string; HapticFeedback?: { impactOccurred: (style: string) => void } }
declare global { interface Window { Telegram?: { WebApp?: WebApp } } }

const faStatus: Record<Job['status'], string> = { queued: 'در صف انتظار', downloading: 'در حال دانلود', sending: 'ارسال به تلگرام', completed: 'تکمیل شده', failed: 'ناموفق', cancelled: 'لغو شده' }
const enStatus: Record<Job['status'], string> = { queued: 'Queued', downloading: 'Downloading', sending: 'Sending to Telegram', completed: 'Completed', failed: 'Failed', cancelled: 'Cancelled' }
const translations = {
  fa: { hero: 'یک لینک. یک دانلود.', subtitle: 'رسانه‌های مجاز را ساده و سریع به تلگرامت بفرست.', placeholder: 'لینک ویدیو یا صدا را اینجا وارد کن', analyze: 'بررسی لینک', preview: 'پیش‌نمایش رسانه', video: 'ویدیو', audio: 'صدا (MP3)', quality: 'کیفیت', start: 'شروع دانلود', activity: 'آخرین فعالیت‌ها', all: 'مشاهده همه', history: 'تاریخچه', home: 'خانه', settings: 'تنظیمات', noHistory: 'هنوز دانلودی ثبت نشده', logout: 'تازه‌سازی ورود', profile: 'پروفایل', language: 'زبان', warning: 'فقط رسانه‌هایی را دریافت کن که اجازه ذخیره‌سازی آن‌ها را داری.', connected: 'اتصال برقرار است', demo: 'حالت آزمایشی', canceled: 'لغو درخواست', paste: 'چسباندن', supported: 'پلتفرم‌های پشتیبانی‌شده', processing: 'وضعیت عملیات', retry: 'دانلود دوباره', admin: 'آمار مدیریت', telegramHint: 'برای دریافت فایل، ابتدا در چت ربات /start را بزن.', duration: 'مدت' },
  en: { hero: 'One link. One download.', subtitle: 'Send permitted media straight to your Telegram chat.', placeholder: 'Paste a video or audio URL here', analyze: 'Analyze link', preview: 'Media preview', video: 'Video', audio: 'Audio (MP3)', quality: 'Quality', start: 'Start download', activity: 'Recent activity', all: 'See all', history: 'History', home: 'Home', settings: 'Settings', noHistory: 'No downloads yet', logout: 'Reconnect account', profile: 'Profile', language: 'Language', warning: 'Download only media you own or have permission to save.', connected: 'Connected', demo: 'Demo mode', canceled: 'Cancel job', paste: 'Paste', supported: 'Supported platforms', processing: 'Processing status', retry: 'Try again', admin: 'Admin statistics', telegramHint: 'Start the bot in a private Telegram chat before receiving files.', duration: 'Duration' },
}

function formatDuration(seconds: number | null): string {
  if (!seconds) return '—'
  const minutes = Math.floor(seconds / 60)
  return `${minutes}:${String(Math.floor(seconds % 60)).padStart(2, '0')}`
}

function friendlyError(error: unknown): string {
  return error instanceof Error ? error.message : 'خطای غیرمنتظره. دوباره تلاش کن.'
}

export default function App() {
  const [lang, setLang] = useState<'fa' | 'en'>(() => localStorage.getItem('tgdown-language') === 'en' ? 'en' : 'fa')
  const t = translations[lang]
  const [tab, setTab] = useState<Tab>('home')
  const [profile, setProfile] = useState<Profile | null>(null)
  const [authError, setAuthError] = useState('')
  const [authLoading, setAuthLoading] = useState(true)
  const [isDemo, setIsDemo] = useState(false)
  const [musicQuery, setMusicQuery] = useState('')
  const [musicSource, setMusicSource] = useState<'catalog' | 'downloadable'>('catalog')
  const [musicResults, setMusicResults] = useState<MusicTrack[]>([])
  const [musicNotice, setMusicNotice] = useState('')
  const [musicSearched, setMusicSearched] = useState(false)
  const [musicLoading, setMusicLoading] = useState(false)
  const [url, setUrl] = useState('')
  const [media, setMedia] = useState<MediaInfo | null>(null)
  const [kind, setKind] = useState<'video' | 'audio'>('video')
  const [quality, setQuality] = useState('best')
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState('')
  const [jobs, setJobs] = useState<Job[]>([])
  const [activeId, setActiveId] = useState<string | null>(null)
  const [stats, setStats] = useState<{ users: number; jobs: number; completed: number; failed: number; active: number } | null>(null)
  const currentJob = jobs.find(job => job.id === activeId)

  const refresh = useCallback(async () => {
    try {
      const updated = await api.history()
      setJobs(updated)
      setActiveId(prev => prev || updated.find(job => ['queued', 'downloading', 'sending'].includes(job.status))?.id || null)
    } catch (exc) { console.warn('History unavailable:', friendlyError(exc)) }
  }, [])

  useEffect(() => {
    let alive = true
    const init = async () => {
      try {
        const tg = window.Telegram?.WebApp
        if (tg?.initData) { tg.ready(); tg.expand() }
        let login
        if (tg?.initData) login = await api.auth(tg.initData)
        else {
          // Works only when DEV_MODE=true and the API is bound to localhost.
          login = await api.demo()
          if (alive) setIsDemo(true)
        }
        if (!alive) return
        setToken(login.token)
        setProfile(login.profile)
        const data = await api.history()
        if (alive) {
          setJobs(data)
          setActiveId(data.find(job => ['queued', 'downloading', 'sending'].includes(job.status))?.id || null)
        }
      } catch (exc) {
        if (alive) setAuthError(friendlyError(exc))
      } finally { if (alive) setAuthLoading(false) }
    }
    void init()
    return () => { alive = false }
  }, [])

  useEffect(() => {
    document.documentElement.lang = lang
    document.documentElement.dir = lang === 'fa' ? 'rtl' : 'ltr'
    localStorage.setItem('tgdown-language', lang)
  }, [lang])

  useEffect(() => {
    const running = jobs.some(job => ['queued', 'downloading', 'sending'].includes(job.status))
    if (!profile || !running) return
    const timer = window.setInterval(() => { void refresh() }, 2100)
    return () => window.clearInterval(timer)
  }, [jobs, profile, refresh])

  const analyze = async () => {
    setError(''); setMedia(null); setBusy(true)
    try {
      const data = await api.analyze(url.trim())
      setMedia(data)
      setQuality('best')
      setKind('video')
      window.Telegram?.WebApp?.HapticFeedback?.impactOccurred('light')
    } catch (exc) { setError(friendlyError(exc)) } finally { setBusy(false) }
  }

  const create = async () => {
    setError(''); setBusy(true)
    try {
      const result = await api.create(url.trim(), kind, kind === 'audio' ? 'best' : quality)
      setJobs(old => [result, ...old])
      setActiveId(result.id)
      setMedia(null)
      window.Telegram?.WebApp?.HapticFeedback?.impactOccurred('medium')
    } catch (exc) { setError(friendlyError(exc)) } finally { setBusy(false) }
  }

  const searchMusic = async () => {
    setError('')
    setMusicNotice('')
    setMusicResults([])
    setMusicSearched(false)
    setMusicLoading(true)
    try {
      const response = await api.searchMusic(musicQuery.trim(), musicSource)
      setMusicResults(response.results)
      setMusicNotice(response.notice)
      setMusicSearched(true)
    } catch (exc) { setError(friendlyError(exc)) } finally { setMusicLoading(false) }
  }

  const downloadMusic = async (track: MusicTrack) => {
    if (!track.downloadable || !track.id.startsWith('jam:')) return
    setError(''); setBusy(true)
    try {
      const result = await api.downloadMusic(Number(track.id.slice(4)))
      setJobs(old => [result, ...old])
      setActiveId(result.id)
      setTab('home')
      window.Telegram?.WebApp?.HapticFeedback?.impactOccurred('medium')
    } catch (exc) { setError(friendlyError(exc)) } finally { setBusy(false) }
  }

  const changeMusicSource = (source: 'catalog' | 'downloadable') => {
    setMusicSource(source)
    setMusicResults([])
    setMusicNotice('')
    setMusicSearched(false)
    setError('')
  }

  const paste = async () => {
    try { const value = await navigator.clipboard.readText(); setUrl(value); setMedia(null); setError('') }
    catch { setError(lang === 'fa' ? 'دسترسی به کلیپ‌بورد ممکن نیست؛ لینک را دستی وارد کن.' : 'Clipboard access unavailable. Paste manually.') }
  }

  const cancel = async (id: string) => {
    try { const updated = await api.cancel(id); setJobs(old => old.map(job => job.id === id ? updated : job)) }
    catch (exc) { setError(friendlyError(exc)) }
  }

  const loadStats = async () => {
    try { setStats(await api.stats()) }
    catch (exc) { setError(friendlyError(exc)) }
  }

  const signOut = () => {
    sessionStorage.removeItem('tgdown-token')
    window.location.reload()
  }

  const statusLabel = (status: Job['status']) => lang === 'fa' ? faStatus[status] : enStatus[status]

  return <div className="app-shell">
    <div className="ambient ambient-one" /><div className="ambient ambient-two" />
    <header className="topbar">
      <div className="brand"><div className="brand-mark"><ArrowDownToLine size={21} strokeWidth={2.8} /></div><div><strong>Tg DownBot</strong><span>MEDIA DELIVERY ENGINE</span></div></div>
      <div className="avatar" title={profile?.first_name || 'User'}><UserRound size={20} /></div>
    </header>

    {authLoading ? <div className="loading-panel"><Loader2 className="spin" size={35}/><p>{lang === 'fa' ? 'اتصال به سیستم...' : 'Connecting...'}</p></div> :
      authError ? <section className="error-view"><CircleAlert size={36}/><h2>{lang === 'fa' ? 'ورود ممکن نشد' : 'Sign-in failed'}</h2><p>{authError}</p><p className="muted">{lang === 'fa' ? 'برای نسخه واقعی، مینی‌اپ را از داخل تلگرام باز کن. برای تست محلی، DEV_MODE را فعال کن.' : 'Open inside Telegram, or enable DEV_MODE for local testing.'}</p></section> : <>
      {isDemo && <div className="demo-banner"><Sparkles size={15}/>{t.demo} — {lang === 'fa' ? 'برای تست داخلی، نه استفاده عمومی' : 'local testing only'}</div>}
      {tab === 'home' && <main className="main-content">
        <div className="section-eyebrow"><span className="pulse-dot"/>{t.connected} <span className="eyebrow-line"/></div>
        <h1>{t.hero}</h1><p className="lead">{t.subtitle}</p>
        <div className="link-panel">
          <div className="field-label"><Link2 size={16}/>{lang === 'fa' ? 'آدرس رسانه' : 'Media link'}</div>
          <div className="input-wrap"><input aria-label="Media URL" spellCheck={false} dir="ltr" placeholder="https://youtube.com/watch?v=..." value={url} onChange={event => { setUrl(event.target.value); setMedia(null); setError('') }} onKeyDown={event => { if (event.key === 'Enter' && !busy && url) void analyze() }} /><button className="paste-btn" onClick={() => void paste()} aria-label={t.paste}><Clipboard size={17}/></button></div>
          <button disabled={busy || !url.trim() || jobs.some(j => ['queued','downloading','sending'].includes(j.status))} onClick={() => void analyze()} className="primary-btn">{busy ? <Loader2 size={19} className="spin"/> : <Search size={19}/>} {t.analyze} <ArrowLeft size={18}/></button>
        </div>
        {error && <div className="error-toast" role="alert"><CircleAlert size={17}/><span>{error}</span><button aria-label="Close" onClick={() => setError('')}><X size={16}/></button></div>}
        {media && <section className="preview-panel"><div className="section-title"><PlayCircle size={18}/><h2>{t.preview}</h2></div><div className="media-preview">
          <div className="media-cover">{media.thumbnail ? <img src={media.thumbnail} alt="Media thumbnail"/> : <Video size={38}/>}<span>{media.platform}</span></div>
          <div className="media-details"><strong>{media.title}</strong><small><Clock3 size={13}/>{t.duration}: {formatDuration(media.duration)}</small></div>
        </div><div className="field-label">{lang === 'fa' ? 'فرمت فایل' : 'Media format'}</div><div className="segmented"><button className={kind === 'video' ? 'selected' : ''} onClick={() => setKind('video')}><FileVideo size={17}/>{t.video}</button><button className={kind === 'audio' ? 'selected' : ''} onClick={() => setKind('audio')}><FileAudio size={17}/>{t.audio}</button></div>
        {kind === 'video' && <><div className="field-label">{t.quality}</div><div className="quality-grid">{media.qualities.map(q => <button key={q} className={quality === q ? 'quality selected' : 'quality'} onClick={() => setQuality(q)}>{q === 'best' ? 'Best' : `${q}p`}</button>)}</div></>}
        <button className="primary-btn" disabled={busy} onClick={() => void create()}><Download size={19}/>{t.start}<ArrowLeft size={18}/></button></section>}
        {currentJob && <section className="job-panel"><div className="section-title"><span className={`status-dot ${currentJob.status}`}/><h2>{t.processing}</h2><span className="job-status">{statusLabel(currentJob.status)}</span></div><p className="job-subtitle">{currentJob.message || currentJob.platform}</p><div className="progress-row"><span>{currentJob.platform} · {currentJob.kind === 'audio' ? 'MP3' : 'Video'}</span><strong>{Math.round(currentJob.progress)}%</strong></div><div className="progress-track"><div className="progress-fill" style={{width:`${currentJob.progress}%`}} /></div>
          {currentJob.status === 'completed' && <div className="status-message success"><CheckCircle2 size={18}/>{currentJob.message}</div>}
          {currentJob.status === 'failed' && <div className="status-message fail"><CircleAlert size={18}/>{currentJob.error}</div>}
          {['queued','downloading'].includes(currentJob.status) && <button className="link-button" onClick={() => void cancel(currentJob.id)}><Square size={13}/>{t.canceled}</button>}
        </section>}
        <div className="section-title spacing-top"><h2>{t.supported}</h2><Globe2 size={18}/></div>
        <div className="platforms">{['YouTube','Instagram','SoundCloud','TikTok','Vimeo'].map((platform, index) => <div className="platform" key={platform}><span className={`platform-symbol p${index}`}>{platform.substring(0, 1)}</span><small>{platform}</small></div>)}</div>
        <div className="section-title history-title"><h2>{t.activity}</h2><button onClick={() => setTab('history')} className="see-all">{t.all}<ArrowLeft size={15}/></button></div>
        <div className="recent-list">{jobs.slice(0, 3).length ? jobs.slice(0, 3).map(job => <JobRow key={job.id} job={job} statusLabel={statusLabel} onClick={() => setActiveId(job.id)} />) : <p className="empty-text">{t.noHistory}</p>}</div>
        <div className="notice"><ShieldCheck size={17}/><span>{t.warning}</span></div>
      </main>}
      {tab === 'music' && <main className="main-content music-page">
        <div className="section-eyebrow"><span className="pulse-dot"/>{lang === 'fa' ? 'کتابخانه موسیقی' : 'Music discovery'} <span className="eyebrow-line"/></div>
        <h1>{lang === 'fa' ? 'آهنگتو پیدا کن.' : 'Discover your song.'}</h1>
        <p className="lead">{lang === 'fa' ? 'اسم آهنگ، خواننده یا آلبوم را جست‌وجو کن؛ آثار قابل‌دانلود را مستقیم در تلگرام دریافت کن.' : 'Search songs, artists or albums. Download artist-approved tracks to Telegram.'}</p>
        <div className="link-panel">
          <div className="field-label"><Music2 size={16}/>{lang === 'fa' ? 'جست‌وجوی موسیقی' : 'Music search'}</div>
          <div className="input-wrap"><input aria-label="Search music" value={musicQuery} onChange={event => setMusicQuery(event.target.value)} onKeyDown={event => { if (event.key === 'Enter' && musicQuery.trim().length >= 2 && !musicLoading) void searchMusic() }} placeholder={lang === 'fa' ? 'نام آهنگ، خواننده یا آلبوم...' : 'Song, artist, or album...'} maxLength={100} /></div>
          <div className="segmented music-segmented"><button aria-pressed={musicSource === 'catalog'} className={musicSource === 'catalog' ? 'selected' : ''} onClick={() => changeMusicSource('catalog')}><Search size={15}/>{lang === 'fa' ? 'همه آثار' : 'Music catalog'}</button><button aria-pressed={musicSource === 'downloadable'} className={musicSource === 'downloadable' ? 'selected' : ''} onClick={() => changeMusicSource('downloadable')}><Download size={15}/>{lang === 'fa' ? 'قابل دانلود' : 'Downloadable'}</button></div>
          <button className="primary-btn" disabled={musicLoading || musicQuery.trim().length < 2} onClick={() => void searchMusic()}>{musicLoading ? <Loader2 size={18} className="spin"/> : <Search size={18}/>} {lang === 'fa' ? 'جست‌وجوی آهنگ' : 'Search songs'} <ArrowLeft size={17}/></button>
        </div>
        {error && <div className="error-toast" role="alert"><CircleAlert size={17}/><span>{error}</span><button aria-label="Close" onClick={() => setError('')}><X size={16}/></button></div>}
        {musicNotice && <div className="notice music-notice"><ShieldCheck size={17}/><span>{musicSource === 'catalog' ? (lang === 'fa' ? 'نتایج کاتالوگ فقط اطلاعات آهنگ هستند و به معنی وجود فایل دانلودی نیستند.' : 'Catalog results are metadata only, not downloadable files.') : musicNotice === 'Configure JAMENDO_CLIENT_ID to enable music downloads' ? (lang === 'fa' ? 'برای فعال شدن دانلود موسیقی، شناسه API سرویس Jamendo باید در تنظیمات پروژه وارد شود.' : 'Set JAMENDO_CLIENT_ID in your project settings to enable music downloads.') : (lang === 'fa' ? 'فقط آهنگ‌هایی نمایش داده می‌شوند که وضعیت مجوز آن‌ها مشخص است.' : musicNotice)}</span></div>}
        {musicSearched && <div className="section-title music-heading"><h2>{lang === 'fa' ? `نتایج (${musicResults.length})` : `Results (${musicResults.length})`}</h2></div>}
        {musicSearched && !musicResults.length && <div className="empty-large"><Music2 size={32}/><p>{lang === 'fa' ? 'نتیجه‌ای پیدا نشد یا منبع دانلود تنظیم نشده است.' : 'No results found, or the download provider is not configured.'}</p></div>}
        <div className="music-results">
          {musicResults.map(track => <article className="music-track" key={track.id}>
            <div className="music-art">{track.cover ? <img src={track.cover} alt="" loading="lazy"/> : <Music2 size={27}/>}</div>
            <div className="music-meta"><strong title={track.title}>{track.title}</strong><span>{track.artist || 'Unknown artist'}</span><small>{track.album ? `${track.album} · ` : ''}{formatDuration(track.duration)} · {track.provider}</small></div>
            <div className="music-actions">
              {track.downloadable ? <button aria-label={lang === 'fa' ? `دانلود ${track.title}` : `Download ${track.title}`} title="Download to Telegram" disabled={busy || jobs.some(job => ['queued','downloading','sending'].includes(job.status))} onClick={() => void downloadMusic(track)}><Download size={18}/></button> : <a href={track.source_url} target="_blank" rel="noreferrer noopener" aria-label="Open provider page" title={lang === 'fa' ? 'مشاهده منبع' : 'Open source'}><ExternalLink size={17}/></a>}
              {track.license_url && <a className="music-license" href={track.license_url} target="_blank" rel="noreferrer noopener" title="Creative Commons license">CC</a>}
            </div>
          </article>)}
        </div>
        <div className="notice"><ShieldCheck size={17}/><span>{lang === 'fa' ? 'جست‌وجو در تمام آثار جهان تضمین نمی‌شود. دانلود فقط در صورت اجازه صاحب اثر فعال است.' : 'Worldwide coverage is not guaranteed. Downloads are available only with artist permission.'}</span></div>
      </main>}
      {tab === 'history' && <main className="main-content"><div className="page-head"><History size={25}/><h1>{t.history}</h1><button className="icon-button" title="Refresh" onClick={() => void refresh()}><RefreshCw size={17}/></button></div><p className="lead small">{lang === 'fa' ? '۳۰ درخواست اخیر خودت و وضعیت آن‌ها' : 'Your 30 most recent requests and their status'}</p><button className="clear-btn" disabled={!jobs.some(j=>['completed','failed','cancelled'].includes(j.status))} onClick={async () => { if (!window.confirm(lang === 'fa' ? 'سوابق پایان‌یافته پاک شوند؟' : 'Delete finished history?')) return; try { await api.clearHistory(); await refresh(); setActiveId(null) } catch(exc) { setError(friendlyError(exc)) } }}><X size={14}/>{lang === 'fa' ? 'پاک کردن سوابق پایان‌یافته' : 'Clear finished history'}</button><div className="recent-list history-list">{jobs.length ? jobs.map(job => <JobRow key={job.id} job={job} statusLabel={statusLabel} onClick={() => { setActiveId(job.id); setTab('home') }}/>) : <div className="empty-large"><History size={35}/><p>{t.noHistory}</p></div>}</div></main>}
      {tab === 'settings' && <main className="main-content"><div className="page-head"><Settings2 size={25}/><h1>{t.settings}</h1></div><section className="settings-card"><div className="setting-row"><div className="setting-icon"><UserRound size={19}/></div><div><strong>{profile?.first_name}</strong><small>{profile?.username ? `@${profile.username}` : `ID: ${profile?.id}`}</small></div><CheckCircle2 className="setting-check" size={20}/></div><div className="setting-row"><div className="setting-icon"><Globe2 size={19}/></div><div><strong>{t.language}</strong><small>Persian / English</small></div><select aria-label="Language" value={lang} onChange={event => setLang(event.target.value as 'fa' | 'en')}><option value="fa">فارسی</option><option value="en">English</option></select></div><div className="setting-row"><div className="setting-icon"><Moon size={19}/></div><div><strong>{lang === 'fa' ? 'ظاهر برنامه' : 'Appearance'}</strong><small>Midnight Blue</small></div></div><div className="setting-row"><div className="setting-icon"><ShieldCheck size={19}/></div><div><strong>{lang === 'fa' ? 'حریم خصوصی' : 'Privacy'}</strong><small>{lang === 'fa' ? 'فایل‌های موقت پس از پردازش حذف می‌شوند.' : 'Temporary files are deleted after processing.'}</small></div></div></section><div className="notice"><ShieldCheck size={17}/><span>{t.telegramHint}</span></div>{profile?.is_admin && <section className="settings-card"><div className="setting-row"><div><strong>{t.admin}</strong><small>Users · Jobs · Status</small></div><button className="link-button" onClick={() => void loadStats()}><RefreshCw size={16}/></button></div>{stats && <div className="stats-grid">{Object.entries(stats).map(([key, val]) => <div key={key}><strong>{val}</strong><small>{key}</small></div>)}</div>}</section>}<button className="secondary-btn" onClick={signOut}>{t.logout}<ExternalLink size={16}/></button></main>}
      <nav className="tabbar" aria-label="Main navigation"><button aria-current={tab === 'home' ? 'page' : undefined} onClick={() => setTab('home')} className={tab === 'home' ? 'active' : ''}><Home size={21}/><span>{t.home}</span></button><button aria-current={tab === 'music' ? 'page' : undefined} onClick={() => setTab('music')} className={tab === 'music' ? 'active' : ''}><Music2 size={21}/><span>{lang === 'fa' ? 'موسیقی' : 'Music'}</span></button><button aria-current={tab === 'history' ? 'page' : undefined} onClick={() => { setTab('history'); void refresh() }} className={tab === 'history' ? 'active' : ''}><History size={21}/><span>{t.history}</span></button><button aria-current={tab === 'settings' ? 'page' : undefined} onClick={() => setTab('settings')} className={tab === 'settings' ? 'active' : ''}><Settings2 size={21}/><span>{t.settings}</span></button></nav>
    </>}
  </div>
}

function JobRow({ job, statusLabel, onClick }: { job: Job; statusLabel: (status: Job['status']) => string; onClick: () => void }) {
  const done = job.status === 'completed'
  return <button className="job-row" onClick={onClick}><div className="job-icon">{job.kind === 'audio' ? <AudioLines size={19}/> : <FileVideo size={19}/>}</div><div className="job-meta"><strong>{job.title !== 'Media download' ? job.title : `${job.platform} · ${job.kind === 'audio' ? 'Audio' : 'Video'}`}</strong><small>{new Date(job.created_at).toLocaleDateString()} · {statusLabel(job.status)}</small></div>{done ? <CheckCircle2 className="finished-icon" size={19}/> : job.status === 'failed' ? <CircleAlert className="failed-icon" size={19}/> : <ArrowRight className="muted-icon" size={17}/>}</button>
}
