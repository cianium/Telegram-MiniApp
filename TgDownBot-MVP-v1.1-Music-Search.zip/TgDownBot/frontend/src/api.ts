export type MediaInfo = {
  title: string
  platform: string
  thumbnail: string
  duration: number | null
  qualities: string[]
  audio_available: boolean
}
export type Job = {
  id: string
  title: string
  platform: string
  kind: 'audio' | 'video'
  quality: string
  status: 'queued' | 'downloading' | 'sending' | 'completed' | 'failed' | 'cancelled'
  progress: number
  error: string
  message: string
  created_at: string
}
export type MusicTrack = {
  id: string
  title: string
  artist: string
  album: string
  provider: 'MusicBrainz' | 'Jamendo'
  duration: number | null
  cover: string
  preview: string
  downloadable: boolean
  license_url: string
  source_url: string
}
export type MusicSearch = { results: MusicTrack[]; configured: boolean; source: 'catalog' | 'downloadable'; notice: string }
export type Profile = { id: number; first_name: string; username: string; is_admin?: boolean }
export type AuthResult = { token: string; profile: Profile; is_admin: boolean }

let token = sessionStorage.getItem('tgdown-token') || ''

export function setToken(value: string) {
  token = value
  sessionStorage.setItem('tgdown-token', value)
}

async function request<T>(endpoint: string, options: RequestInit = {}): Promise<T> {
  let response: Response
  try {
    response = await fetch(`/api${endpoint}`, {
      ...options,
      headers: { 'Content-Type': 'application/json', ...(token ? { Authorization: `Bearer ${token}` } : {}), ...options.headers },
    })
  } catch {
    throw new Error('اتصال به API برقرار نیست. Backend را اجرا کن.')
  }
  const body = await response.json().catch(() => ({}))
  if (!response.ok) throw new Error(typeof body.detail === 'string' ? body.detail : `HTTP ${response.status}`)
  return body as T
}

export const api = {
  auth: (init_data: string) => request<AuthResult>('/auth/telegram', { method: 'POST', body: JSON.stringify({ init_data }) }),
  demo: () => request<AuthResult>('/auth/demo', { method: 'POST' }),
  me: () => request<Profile>('/me'),
  searchMusic: (q: string, source: 'catalog' | 'downloadable') => request<MusicSearch>(`/music/search?q=${encodeURIComponent(q)}&source=${source}`),
  downloadMusic: (trackId: number) => request<Job>('/music/jobs', { method: 'POST', body: JSON.stringify({ track_id: trackId }) }),
  analyze: (url: string) => request<MediaInfo>('/media/analyze', { method: 'POST', body: JSON.stringify({ url }) }),
  create: (url: string, kind: 'audio' | 'video', quality: string) => request<Job>('/jobs', { method: 'POST', body: JSON.stringify({ url, kind, quality }) }),
  history: () => request<Job[]>('/jobs'),
  clearHistory: () => request<{ deleted: number }>('/history', { method: 'DELETE' }),
  job: (id: string) => request<Job>(`/jobs/${encodeURIComponent(id)}`),
  cancel: (id: string) => request<Job>(`/jobs/${encodeURIComponent(id)}`, { method: 'DELETE' }),
  stats: () => request<{ users: number; jobs: number; completed: number; failed: number; active: number }>('/admin/stats'),
}
